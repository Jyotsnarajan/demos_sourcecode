/* mt19937ar.c */

#ifdef __cplusplus
extern "C" {
#endif

void mt_init_genrand(unsigned long s);
double mt_genrand_res53(void);

#ifdef __cplusplus
}
#endif
